class HumanPlayer
    attr_reader :mark_value
    def initialize(mark =gets.chomp)
        @mark_value = gets.chomp
    end

    def get_position
        begin
            print "enter a position with coordinates separated with a space like `4 7`"
            input = gets.chomp.split.map {|el| el.to_i}
            if input.length != 2
                raise
            end
            input
        rescue
            puts "error message blah"           # How to print error message and call method again??
            self.get_position
        end
    end
        
end
# human = HumanPlayer.new
# p "did it work"
# p human.mark_value
# p human.get_position
# p "what is the position"

# begin
#   # ...
# rescue => exception
#   warn exception.message
#   raise # re-raise the current exception
# end