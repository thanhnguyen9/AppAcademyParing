require "byebug"

class Board
    attr_accessor :grid

    def initialize
        @grid = Array.new(3){Array.new(3, "_")}
    end

    def valid?(position) # position = [row_num, col_num]
        num_grid_row = @grid.length
        num_grid_col = @grid[0].length
        check_row_num = position[0]
        check_col_num = position[1]

        if !(0...num_grid_row).include?(check_row_num) || !(0...num_grid_row).include?(check_col_num)
            return false
        end
        true
    end

    def empty?(pos)     # pos = [row_num, col_num]
        @grid[pos[0]][pos[1]] == "_"
    end

    def place_mark(pos, mark)
        if self.valid?(pos) && self.empty?(pos)
            @grid[pos[0]][pos[1]] = mark
        else
            raise ("Not a valid position")
        end
    end

    def print_board
        @grid.each do |sub|
            (0...sub.length-1).each do |i|
                print sub[i]
                print " "
            end
            print sub[-1]
            print "\n"
        end
    end

    def win_row?(mark)
        @grid.any? { |sub| sub.all? {|el| el == mark}}
    end

    def win_col?(mark)
        @grid.transpose.any? { |sub| sub.all? {|el| el == mark}}
    end

    def win_diagonal?(mark)
        new_arr = []
        (0...@grid[0].length).each do |i|
            new_arr << grid[i][i]
        end
        
        return true if new_arr.all? {|el| el == mark}

        new_arr = []
        i = 0
        k = @grid[0].length - 1
        while i < @grid.length
            new_arr << grid[i][k] # 0 2
            i += 1                  # 1
            k -= 1                  # 1
        end

        return true if new_arr.all? {|el| el == mark}
        false
    end

    def win?(mark)
        win_row?(mark) || win_col?(mark) || win_diagonal?(mark)
    end


    def empty_positions?
        @grid.flatten.any? { |el| el == "_"}
    end
end

# # test for #win_row?(mark)
# b1 = Board.new
# b1.place_mark([0,0], :X)
# b1.place_mark([0,1], :X)
# b1.place_mark([0,2], :X)
# b1.print_board
# p b1.win_row?(:X)

# # test for #win_col?(mark)
# b2 = Board.new
# b2.place_mark([0,0], :O)
# b2.place_mark([1,0], :O)
# b2.place_mark([2,0], :O)
# b2.print_board
# p b2.win_col?(:O)
# p b2.win_col?(:X)

# # test for #win_diagonal?(mark)
# b3 = Board.new
# b3.place_mark([0,2], :O)
# b3.place_mark([1,1], :O)
# b3.place_mark([2,0], :O)
# b3.print_board
# p b3.win_diagonal?(:O)
# p b3.win?(:O)

# test 2 for #win_diagonal?(mark)
b4 = Board.new
b4.place_mark([0,0], :O)
b4.place_mark([1,1], :O)
b4.place_mark([2,2], :O)
b4.print_board
p b4.win_diagonal?(:O)
p b4.win?(:O)
p b4.empty_positions?
b4.place_mark([0,1], :X)
b4.place_mark([0,2], :X)
b4.place_mark([2,0], :X)
b4.place_mark([2,1], :X)
b4.place_mark([1,0], :X)
b4.place_mark([1,2], :X)
p b4.empty_positions?
b4.print_board