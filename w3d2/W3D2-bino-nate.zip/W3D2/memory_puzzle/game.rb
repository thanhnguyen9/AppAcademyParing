require_relative 'board.rb'
require_relative 'card.rb'
require_relative 'human_player.rb'

class Game
    def initialize
        @board = Board.new
        @previous_guess = "previous_guess"

        @player = HumanPlayer.new

        @board.populate 
        @player.prompt
        @board.render
        sleep(5)

#loop
        until @board.won?
            
        
            system("clear")
            @board.print_hidden_grid
            
            @player.get_input

            @board.reveal(@player.user_input_1)
            @board.reveal(@player.user_input_2)

                    
            @board.print_hidden_grid
            sleep(3)
            if @board[@player.user_input_1] != @board[@player.user_input_2]
                @board[@player.user_input_1].hide
                @board[@player.user_input_2].hide
            end


        end
        
        puts "Congratulation"
    end
end