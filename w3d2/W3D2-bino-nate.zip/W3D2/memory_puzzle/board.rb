
require 'byebug'
require_relative 'card.rb'

class Board
    faces = ["1","2","3","4", "5", "6", "7", "8", "9","10","J","Q","K","A"]
    CARDS = faces.map! { |el| el = Card.new(el) }
    EMPTY = Card.new('_')
    attr_reader :size
    def initialize(size=2)
        @size = size
        @grid = Array.new(size) {Array.new(size, Card.new('_'))}

    end

    def [](pos)
      row, col = pos
      @grid[row][col]
    end
    def []=(pos, val)
      row, col = pos
      @grid[row][col] = val
    end

    def valid?(pos)
      row, col = pos
      @grid[row][col] == EMPTY
    end

    def full?
      @grid.flatten.none? { |el| el == EMPTY}
    end

    def populate
       deck = CARDS.shuffle
       i = 0
      until self.full?
        first_card = deck[i]
        count = 0
        while count < 2
            #  debugger
            row = rand(0...@size)
            col = rand(0...@size)
            pos = [row, col]
            if self.valid?(pos)
              self[pos] = Card.new(first_card.face_value)
              count += 1
            end
        end
        count = 0
        i += 1
      end
    end

    def render
      print "      "+ (0...@size).to_a.join("    ")
      puts " "
      (0...@size).each do |i|
        puts " #{i}    #{@grid[i].join("    ")} "
      end
    end



    def hidden_grid
        new_arr = []
        @grid.each do |row|
          temp = []
            row.each do |el|
                if el.status == "hidden"
                    temp << '#'
                else
                    temp << el.face_value
                end
            end
            new_arr << temp
        end
        new_arr
    end

    def print_hidden_grid
      print "      "+ (0...@size).to_a.join("    ")
      puts " "
      (0...@size).each do |i|
        
        puts " #{i}    #{self.hidden_grid[i].join("    ")} "
      end

    end

    def reveal(pos)
      if self[pos].status == "hidden"
        self[pos].reveal
      end
    end

    def won?
      if @grid.flatten.all? { |card| card.status == "revealed"}
        puts "you won!"
        
      end
      
    end




# board.hidden_grid -->
end