require_relative 'board.rb'

class HumanPlayer
    attr_reader :user_input_2, :user_input_1
    def initialize
        @user_input_1 = nil
        @user_input_2 = nil
    end
    def prompt
        puts "Here's your game board. You have 15s to memorize before first guess..."
    end
    def get_input
        puts "Make your first guess with form 0 0"
        @user_input_1 = gets.chomp.split(' ').map(&:to_i)
        puts "Now your second guess"
        @user_input_2 = gets.chomp.split(' ').map(&:to_i)
    end


    
end