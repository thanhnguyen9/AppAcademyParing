class Card
  attr_accessor :face_value, :status
  def initialize(face_value)
    @face_value = face_value
    @status = "hidden"
  end

  def hide
    
      self.status = "hidden"
      return "#"
  end

  def reveal

    self.status = "revealed"
    return self.face_value
    
      
  end

  def to_s
    self.face_value
  end

  def ==(other_card)
    self.face_value  == other_card.face_value
  end



end